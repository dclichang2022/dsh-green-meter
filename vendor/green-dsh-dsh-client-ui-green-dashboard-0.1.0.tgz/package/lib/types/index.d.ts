/** Host loader entry for the browser-only green dashboard widget. */
/** Provides no host-side behavior. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map