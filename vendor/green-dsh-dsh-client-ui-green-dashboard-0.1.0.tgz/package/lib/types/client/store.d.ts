import type { GreenMeterProjection } from '@deepseek-ai/dsh-green-meter/client';
/** Cross-session aggregate read from the green-meter ledger by the desktop shell. */
export interface GlobalTotals {
    /** Distinct session ids accounted in the ledger. */
    readonly sessions: number;
    readonly requests: number;
    readonly inputTokens: number;
    readonly cachedTokens: number;
    readonly outputTokens: number;
    readonly reasoningTokens: number;
    readonly energyJ: number;
    readonly carbonG: number;
}
export type DashboardState = {
    session: GreenMeterProjection | null;
    global: GlobalTotals | null;
    collapsed: boolean;
};
declare global {
    interface Window {
        /** Electron bridge exposed by the desktop shell; absent in a plain browser. */
        greenDesktop?: {
            getGlobalTotals(): Promise<GlobalTotals | null>;
        };
    }
}
export declare function subscribeDashboard(listener: () => void): () => void;
export declare function getDashboardState(): DashboardState;
export declare function useDashboardState(): DashboardState;
export declare const dashboardActions: {
    setSession: (session: GreenMeterProjection | null) => void;
    setGlobal: (global: GlobalTotals | null) => void;
    toggle: () => void;
    collapse: () => void;
};
//# sourceMappingURL=store.d.ts.map