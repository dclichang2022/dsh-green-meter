/**
 * DashboardCard: the pinned top-right FreeToken-style readout rendered in
 * the frame-wide `shell.overlay` layer. Root-scoped: it reads the shared
 * dashboard store (the session-scoped dock mirror owns the data reads).
 *
 * Two states: a compact pill (default) with the live carbon + saved-cost
 * headline, and the expanded card with the full local-vs-cloud comparison,
 * per-turn energy bars, the cross-session ledger aggregate (desktop bridge
 * only), and the method-boundary note.
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ResolvedDashboardConfig } from './index.ts';
/** Full card props: shell.overlay owner share + locale seat + resolved config. */
export type DashboardCardProps = PropsRuntime<'shell.overlay'> & PropsLocale<'greenDashboard'> & {
    config: ResolvedDashboardConfig;
};
/** J → J/kJ/MJ, mirroring the /green report's energy formatting. */
export declare function formatEnergy(joules: number): string;
/** Inline SVG per-turn energy bars; renders nothing for an empty series. */
export declare function SparkBars({ values, height }: {
    values: readonly number[];
    height?: number;
}): import("react").JSX.Element | null;
export declare function DashboardCard({ t, config }: DashboardCardProps): import("react").JSX.Element;
//# sourceMappingURL=DashboardCard.d.ts.map