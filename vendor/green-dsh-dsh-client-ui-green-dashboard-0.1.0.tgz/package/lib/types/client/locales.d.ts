/** Dictionary keys of the green dashboard widget. */
export type GreenDashboardKey = 'empty' | 'title' | 'collapse' | 'expand' | 'sessionLabel' | 'globalLabel' | 'savedCnyLabel' | 'savedCny' | 'cloudEquiv' | 'localCost' | 'carbonLabel' | 'cloudCarbon' | 'carbonDeltaPos' | 'carbonDeltaNeg' | 'cacheSaved' | 'energy' | 'requests' | 'tokens' | 'globalRow' | 'methodNote';
export declare const zh: Record<GreenDashboardKey, string>;
export declare const en: Record<GreenDashboardKey, string>;
//# sourceMappingURL=locales.d.ts.map