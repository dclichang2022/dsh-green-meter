import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ResolvedDashboardConfig } from './index.ts';
/** Full mirror props: session-scoped runtime share (useProjection), locale, resolved config. */
export type DashboardMirrorProps = PropsRuntime<'conversation.composer.dock'> & PropsLocale<'greenDashboard'> & {
    config: ResolvedDashboardConfig;
};
/** Hidden data mirror for the dashboard store. */
export declare function DashboardMirror({ useProjection, config }: DashboardMirrorProps): null;
//# sourceMappingURL=DashboardMirror.d.ts.map