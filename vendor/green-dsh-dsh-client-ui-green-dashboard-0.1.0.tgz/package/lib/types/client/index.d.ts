/**
 * Green dashboard surface plugin, browser half: a pinned top-right card in
 * the frame-wide `shell.overlay` layer (FreeToken-style readout) plus a
 * hidden composer-dock mirror that owns the `greenMeter` projection read
 * and the desktop-bridge poll for cross-session ledger totals.
 *
 * The card renders from the shared module-level store — the dock mirror is
 * session-scoped and owns `useProjection('greenMeter')`, the overlay card is
 * root-scoped, so the two surfaces meet in the store exactly like
 * ui-green-meter's panel store.
 *
 * When `window.greenDesktop` (the Electron preload bridge) is absent — plain
 * browser usage — the global section simply stays hidden.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type GreenDashboardKey } from './locales.ts';
export type { GreenDashboardKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Green dashboard copy. */
        greenDashboard: GreenDashboardKey;
    }
}
/** Client row configuration for the savings baseline. */
export interface UiGreenDashboardConfig {
    /** Cloud datacenter grid carbon intensity for the cloud-equivalent estimate, kg CO2e per kWh. */
    readonly cloudCarbonFactorKgPerKwh?: number;
    /** API price per 1M uncached input tokens, CNY. */
    readonly apiPriceCnyPerMInput?: number;
    /** API price per 1M cached input tokens, CNY. */
    readonly apiPriceCnyPerMCached?: number;
    /** API price per 1M output tokens (reasoning included), CNY. */
    readonly apiPriceCnyPerMOutput?: number;
    /** Residential electricity price for ledger-only (global) cost, CNY per kWh. */
    readonly priceCnyPerKwh?: number;
    /** Ledger poll interval for the desktop bridge, ms. */
    readonly refreshMs?: number;
}
/** Required services: the slot registry and the locale service. */
export declare const inject: string[];
/** Resolved config with the shipped defaults. */
export interface ResolvedDashboardConfig {
    readonly cloudCarbonFactorKgPerKwh: number;
    readonly apiPriceCnyPerMInput: number;
    readonly apiPriceCnyPerMCached: number;
    readonly apiPriceCnyPerMOutput: number;
    readonly priceCnyPerKwh: number;
    readonly refreshMs: number;
}
export declare function resolveConfig(config: UiGreenDashboardConfig): ResolvedDashboardConfig;
/**
 * Client plugin body: the hidden dock mirror and the overlay card. The
 * surfaces share the module-level dashboard store (scope-agnostic), so no
 * engine store handle is attached to the registrations.
 */
export declare function apply(ctx: ClientContext, config?: UiGreenDashboardConfig): void;
//# sourceMappingURL=index.d.ts.map